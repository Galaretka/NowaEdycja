function kill (source)
   setElementData ( source, "blood", -10 )
end
addCommandHandler ( "kill", kill )


------- Feito por ~W --------
